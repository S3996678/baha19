import { View, Text, TouchableOpacity } from 'react-native';
import { Link } from 'expo-router';

export default function GeneralPrayerCategories() {
  const categories = [
    { name: 'Aid and Assistance', count: 14 },
    { name: 'Children', count: 5 },
  ];

  return (
    <View style={{ flex: 1, padding: 20, backgroundColor: '#e0f7fa' }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>
        General Prayers
      </Text>
      <TouchableOpacity>
      <Link href="../details">
          <Text>Go to Details Page</Text>
        </Link>
      </TouchableOpacity>
    </View>
  );
}